# Running the code
To run the tests, py.test suite is required. This can be installed via pip:

    pip install pytest

And then to run the tests (run in the directory of test/):

    py.test -s 

